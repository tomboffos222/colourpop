<?php 
ini_set('display_errors',1);
error_reporting(E_ALL);
session_start();

define('ROOT' , dirname(__FILE__));
require_once(ROOT. '/Router.php');
include_once ROOT.'/Db.php';

$Router =new Router();

$Router->run();

 ?>
 


	<?php require './header.php' ?>
	<section class="first">
	
		<a href="">
			<img src="https://colourpop-com-res.cloudinary.com/image/upload/q_auto/w_1940/colourpop/Shopify/Homepage/banners/20_OFF_BannerA_desktop.jpg" alt="">
		</a>
	
	
	</section>
	<section class="second">
		<div class="container container_new">
			<div class="row">
				<div class="col-lg-12">
					<div class="best_sel">
						
						<h2>
							best sellers
						</h2>
						
					</div>
					<div class="owl-carousel owl-slider1">
						<div class="product">
							<a href="">
								<img src="https://cdn.shopify.com/s/files/1/1338/0845/products/whatever_1_340x.jpg?v=1568780270" alt="">
								<h4>
									whatever
								</h4>
								<p>
									shadow palette

								</p>
								<p class="price">
										<span>$18 </span>$14.40
								</p>
								<p>
									can u call it the pallete of the season? duh.
								</p>
								<button> add to bag</button>
							</a>
						</div>
						<div class="product">
							<a href="">
								<img src="https://cdn.shopify.com/s/files/1/1338/0845/products/baby-got-peach_1_340x.jpg?v=1568772040" alt="">
								<h4>
									whatever
								</h4>
								<p>
									shadow palette

								</p>
								<p class="price">
										<span>$18 </span>$14.40
								</p>
								<p>
									can u call it the pallete of the season? duh.
								</p>
								<button> add to bag</button>
							</a>
						</div>
						<div class="product">
							<a href="">
								<img src="https://cdn.shopify.com/s/files/1/1338/0845/products/sweet-talk_4_340x.jpg?v=1572174160" alt="">
								<h4>
									whatever
								</h4>
								<p>
									shadow palette

								</p>
								<p class="price">
										<span>$18 </span>$14.40
								</p>
								<p>
									can u call it the pallete of the season? duh.
								</p>
								<button> add to bag</button>
							</a>
						</div>
						<div class="product">
							<a href="">
								<img src="https://cdn.shopify.com/s/files/1/1338/0845/products/CP_CL_Press_Powder_544-copy_340x.jpg?v=1572898733" alt="">
								<h4>
									whatever
								</h4>
								<p>
									shadow palette

								</p>
								<p class="price">
										<span>$18 </span>$14.40
								</p>
								<p>
									can u call it the pallete of the season? duh.
								</p>
								<button> add to bag</button>
							</a>
						</div>
						<div class="product">
							<a href="">
								<img src="https://cdn.shopify.com/s/files/1/1338/0845/products/whatever_1_340x.jpg?v=1568780270" alt="">
								<h4>
									whatever
								</h4>
								<p>
									shadow palette

								</p>
								<p class="price">
										<span>$18 </span>$14.40
								</p>
								<p>
									can u call it the pallete of the season? duh.
								</p>
								<button> add to bag</button>
							</a>
						</div>
						<div class="product">
							<a href="">
								<img src="https://cdn.shopify.com/s/files/1/1338/0845/products/whatever_1_340x.jpg?v=1568780270" alt="">
								<h4>
									whatever
								</h4>
								<p>
									shadow palette

								</p>
								<p class="price">
										<span>$18 </span>$14.40
								</p>
								<p>
									can u call it the pallete of the season? duh.
								</p>
								<button> add to bag</button>
							</a>
						</div>
					</div>

				</div>

			</div>
		</div>
	</section>
	<section class="third">
		<div class="row">
			<div class="col-lg-6">
				<a href="">
					<img src="https://colourpop-com-res.cloudinary.com/image/upload/q_auto/w_828/colourpop/Shopify/Homepage/banners/HP-B-11.8.jpg" alt="">
					<h5>new sol shimmering face + body highlighter</h5>
					<p>
						shop sol body
					</p>
				</a>
			</div>
			
			<div class="col-lg-6 last">
				<a href="">
					<img src="https://colourpop-com-res.cloudinary.com/image/upload/q_auto/w_828/colourpop/Shopify/Homepage/banners/HP_C_11.7.jpg" alt="">
					<h5>
						#1 beauty hack for glowing skin
					</h5>
					<p>
						20% off fouth ray beauty
					</p>
				</a>
			</div>
		</div>
	</section>
	<section class="fourth">
		<div class="row">
			<div class="col-lg-12">
				<a href="">
					<img src="https://colourpop-com-res.cloudinary.com/image/upload/q_auto/w_1940/colourpop/Shopify/Homepage/banners/HP_A_11.7.gif" alt="" class="billy_desc">
					<img src="https://colourpop-com-res.cloudinary.com/image/upload/q_auto/w_828/colourpop/Shopify/Homepage/banners/HP_A_M_11.7.gif" alt="" class="billy_mob">
				</a>
			</div>
		</div>
	</section>
	<section class="second">
		<div class="container container_new">
			<div class="row">
				<div class="col-lg-12">
					<div class="best_sel">
						
						<h2>
							best sellers
						</h2>
						
					</div>
					<div class="owl-carousel owl-slider1">
						<div class="product">
							<a href="">
								<img src="https://cdn.shopify.com/s/files/1/1338/0845/products/CP_Bitti_PR-copy_340x.jpg?v=1573143258" alt="">
								<h4>
									whatever
								</h4>
								<p>
									shadow palette

								</p>
								<p>
									$18 <span>$14.40</span>
								</p>
								<p>
									can u call it the pallete of the season? duh.
								</p>
								<button> add to bag</button>
							</a>
						</div>
						<div class="product">
							<a href="">
								<img src="https://cdn.shopify.com/s/files/1/1338/0845/products/CP_Bitti_331_Collection-copy_340x.jpg?v=1573143074" alt="">
								<h4>
									whatever
								</h4>
								<p>
									shadow palette

								</p>
								<p>
									$18 <span>$14.40</span>
								</p>
								<p>
									can u call it the pallete of the season? duh.
								</p>
								<button> add to bag</button>
							</a>
						</div>
						<div class="product">
							<a href="">
								<img src="https://cdn.shopify.com/s/files/1/1338/0845/products/CP_Bitti_127-copy_340x.jpg?v=1573144018" alt="">
								<h4>
									whatever
								</h4>
								<p>
									shadow palette

								</p>
								<p>
									$18 <span>$14.40</span>
								</p>
								<p>
									can u call it the pallete of the season? duh.
								</p>
								<button> add to bag</button>
							</a>
						</div>
						<div class="product">
							<a href="">
								<img src="https://cdn.shopify.com/s/files/1/1338/0845/products/CP_Bitti_233_V2-copy_7d986195-c5da-4c2a-a6a3-4efa7943067d_340x.jpg?v=1573146740" alt="">
								<h4>
									whatever
								</h4>
								<p>
									shadow palette

								</p>
								<p>
									$18 <span>$14.40</span>
								</p>
								<p>
									can u call it the pallete of the season? duh.
								</p>
								<button> add to bag</button>
							</a>
						</div>
						<div class="product">
							<a href="">
								<img src="https://cdn.shopify.com/s/files/1/1338/0845/products/whatever_1_340x.jpg?v=1568780270" alt="">
								<h4>
									whatever
								</h4>
								<p>
									shadow palette

								</p>
								<p>
									$18 <span>$14.40</span>
								</p>
								<p>
									can u call it the pallete of the season? duh.
								</p>
								<button> add to bag</button>
							</a>
						</div>
						<div class="product">
							<a href="">
								<img src="https://cdn.shopify.com/s/files/1/1338/0845/products/whatever_1_340x.jpg?v=1568780270" alt="">
								<h4>
									whatever
								</h4>
								<p>
									shadow palette

								</p>
								<p>
									$18 <span>$14.40</span>
								</p>
								<p>
									can u call it the pallete of the season? duh.
								</p>
								<button> add to bag</button>
							</a>
						</div>
					</div>

				</div>

			</div>
		</div>
	</section>
	<section class="fifth">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="social_title">
						<p>
							GET SOCIAL
						</p>
						<h5>
							get featured on instagram #COLOURPOPME
						</h5>
					</div>
					<div class="owl-carousel owl-carousel1 insta_social">
							<img src="https://cdn.dashhudson.com/media/640/1573400736.69634155982.jpeg" alt="">
							<img src="https://cdn.dashhudson.com/media/640/1573404535.238685847356.jpeg" alt="">
							<img src="https://cdn.dashhudson.com/media/640/1573407264.495308933572.jpeg" alt="">
							<img src="https://cdn.dashhudson.com/media/640/1573229926.99315380318.jpeg" alt="">
							<img src="https://cdn.dashhudson.com/media/640/1573400736.69634155982.jpeg" alt="">
							<img src="https://cdn.dashhudson.com/media/640/1573404535.238685847356.jpeg" alt="">
							<img src="https://cdn.dashhudson.com/media/640/1573407264.495308933572.jpeg" alt="">
							<img src="https://cdn.dashhudson.com/media/640/1573229926.99315380318.jpeg" alt="">
					</div>

				</div>
			</div>
		</div>
	</section>
	<section class="sixth">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="social_title">
						<p>
							ABOUT US
						</p>
						<h5>
							made with love in california

						</h5>
					</div>
					<div class="desc_soc">
						It's our mission to redefine luxury beauty by creating amazing products at prices that don't break <br> the bank. Dedicated to newness at lightning speed, we imagine, develop, test, and manufacture all <br>under one roof. We pride ourselves on being cruelty-free, wallet-friendly, and keeping our customers <br>at the center of our world




					</div>
					<button class="watch">watch now</button>
				</div>
			</div>
		</div>
	</section>
	<section class="seventh">
		<div class="row">
			<div class="col-lg-2">
				<a href="">
					<img src="https://cdn.shopify.com/s/files/1/1338/0835/files/order-issues-prp.svg?105559" alt="">
					<p>order issues</p>
				</a>
			</div>
			<div class="col-lg-2">
				<a href="">
					<img src="https://cdn.shopify.com/s/files/1/1338/0835/files/icon-payments-prp.svg?105559" alt="">
					<p>payment & promo</p>
				</a>
			</div>
			<div class="col-lg-2">
				<a href="">
					<img src="https://cdn.shopify.com/s/files/1/1338/0835/files/icon-deliveries-prp.svg?105559" alt="">
					<p>shipping</p>
				</a>
			</div>
			<div class="col-lg-2">
				<a href="">
					<img src="https://cdn.shopify.com/s/files/1/1338/0835/files/icon-refunds-prp.svg?105559" alt="">
					<p>reutrn & refund</p>
				</a>
			</div>
			<div class="col-lg-2">
				<a href="">
					<img src="https://cdn.shopify.com/s/files/1/1338/0835/files/icon-products2-prp.svg?105559" alt="">
					<p>product & stunk</p>
				</a>
			</div>
			<div class="col-lg-2">
				<a href="">
					<img src="https://cdn.shopify.com/s/files/1/1338/0835/files/icon-technical2-prp.svg?105559" alt="">
					<p>technical</p>
				</a>
			</div>
		</div>
	</section>
	<?php require './footer.php'; ?>

	
</body>
	<script src="https://use.fontawesome.com/3acef40cae.js"></script>
	<script  src="/js/jquery.min.js"></script>
	<script src="/js/owl.carousel.min.js"></script>
	<script src="/js/script.js"></script>
</html>