<?php

return array(
	


	
	'cats'=>'prod/cats/list/',
	'cat/show/([0-9]+)'=>'/cat/show/$1',
	'product/list/([0-9]+)'=>'/product/list/$1',

	'cart/addAjax/([0-9]+)'=>'/cart/addAjax/$1',
	'cart/show'=>'/cart/show',
	'child/show/([0-9]+)'=>'/child/show/$1',
	'cart/mob'=>'/cart/mob',
	'cart/delAjax/([0-9]+)'=>'/cart/delAjax/$1',
	

);