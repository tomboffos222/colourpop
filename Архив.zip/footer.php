<section class="eighth">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="title">
						<h2>get exclusive access & 10% off</h2>
						<p>when you sign up for our newsletter!</p>
					</div>
					<div class="search_form">
						<form action="">
							<input type="text" placeholder="email text">
							<input type="submit" value="enter">
						</form>
						<p>
							By entering your email address you will receive promotional updates. Consent is not a condition of purchase. View Privacy Policy. <br>10% off discount eligible for first time customers only. Discount requires a minimum order of $20. Exclusions apply. <br>Your code will be sent via email.


						</p>
					</div>
					<div class="social_links">
						<a href=""><i class="fa fa-facebook" aria-hidden="true"></i></a>
						<a href=""><i class="fa fa-instagram" aria-hidden="true"></i></a>
						<a href=""><i class="fa fa-twitter" aria-hidden="true"></i></a>
						<a href=""><i class="fa fa-snapchat-ghost" aria-hidden="true"></i></a>
						<a href=""><i class="fa fa-youtube" aria-hidden="true"></i></a>
					</div>
					<div class="menu_footer">
						<a href="">about</a>
						<a href="">faq</a>
						<a href="">student discount</a>
						<a href="">terms</a>
						<a href="">privacy policy</a>
						<a href="">contact us</a>
						<a href="">accessibility statement</a>
					</div>
					<div class="rights">
						<a href="">© 2019 SEEDBEAUTY</a>
					</div>
				</div>
			</div>
		</div>
	</section>